// prediction
// 1-when console.log going to be called it will show "born in 1980"
// 2-when console.log going to be called it will show "born in 1980"
// 3- when console.log is called it will show 30 
